# Public release checklist

Before placing the repository URL in a submitted manuscript:

- [ ] Add the final cohort-construction and harmonization scripts from the local project.
- [ ] Add the methods-completion / cohort-flow audit script.
- [ ] Add the final predictor-family stress-test script (working script 18).
- [ ] Add the corrected XGBoost-vs-ridge comparator script(s) (working scripts 16/16b).
- [ ] Add the frozen final table-generation script.
- [ ] Remove all machine-specific absolute paths.
- [ ] Confirm that no raw/row-level ACS PUF data are committed.
- [ ] Confirm that no ACS-prohibited derived data are committed.
- [ ] Commit `renv.lock` from the exact final R environment.
- [ ] Export the Python/conda environment used for GPU XGBoost.
- [ ] Confirm the final app/model objects correspond to the manuscript-locked model specification.
- [ ] Determine whether trained model objects may be redistributed under ACS terms.
- [ ] If permitted, place large model objects in Zenodo/OSF/GitHub Release assets rather than normal Git history.
- [ ] Create a versioned release (for example `v1.0.0-manuscript`).
- [ ] Archive that release in Zenodo (or another DOI-bearing repository).
- [ ] Replace `[GITHUB URL]`, `[ZENODO DOI]`, and `[MODEL ARCHIVE URL]` in the manuscript statement.
- [ ] Add the software license approved for the project.
- [ ] Verify that a fresh clone can execute at least the public pipeline setup without private path assumptions.
