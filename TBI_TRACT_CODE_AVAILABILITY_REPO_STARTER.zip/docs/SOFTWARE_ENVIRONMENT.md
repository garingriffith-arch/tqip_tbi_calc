# Software environment

The included scripts reference the following R packages/namespaces:

- `data.table`
- `ggplot2`
- `grid`
- `parallel`
- `patchwork`
- `reticulate`
- `scales`
- `splines`
- `xgboost`

Final reported development environment:
- R 4.6.0
- R XGBoost 3.2.1.1
- Python XGBoost 3.2.0 with CUDA, invoked through `reticulate`
- Windows x86-64
- NVIDIA RTX 4090 GPU used for final GPU-accelerated model fitting

For the public release, create the dependency lock files on the workstation that generated the frozen final manuscript outputs:

```r
install.packages("renv")
renv::init(bare = TRUE)
renv::snapshot()
```

and export the Python environment, for example:

```bash
conda env export -n tbi-tract-xgb-gpu --from-history > environment.yml
```

Do not hand-edit package versions into a lock file; generate them from the actual final environment.
