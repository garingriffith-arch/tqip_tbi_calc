# TBI-TRACT analytic code

This repository accompanies the TBI-TRACT clinical prediction study using the American College of Surgeons Trauma Quality Improvement Program / Trauma Quality Programs Participant Use Files (ACS TQIP/TQP PUF), 2020-2024.

## Scope

The public repository is intended to document and reproduce the **analytic workflow**, including:

1. cohort construction and variable harmonization;
2. rolling-origin temporal model development/evaluation;
3. categorical resource/disposition and continuous duration prediction;
4. predictor adjudication and sensitivity analyses;
5. subgroup and calibration analyses;
6. final deployment-model fitting; and
7. manuscript table/figure generation.

The patient-level ACS PUF data are **not included in this repository**. Researchers must obtain the relevant PUF files independently and comply with applicable ACS data-use terms.

## Final model architecture

The intended prediction time is **after the initial trauma-center evaluation and diagnostic workup, but before subsequent inpatient disposition and resource utilization**.

Final outputs:

- disposition: home/home health, post-acute facility, death/hospice;
- hospital LOS trajectory: <=7 d, 8-27 d, >=28 d;
- ICU trajectory: no ICU, 1-7 d, >=8 d;
- ventilation trajectory: no ventilation, 1-7 d, >=8 d;
- invasive ICP monitoring probability;
- craniotomy/craniectomy probability;
- hospital LOS Q10/Q50/Q90;
- ICU LOS Q10/Q50/Q90 conditional on ICU use;
- ventilator duration Q10/Q50/Q90 conditional on ventilation.

The final pragmatic clinical predictor backbone excludes **helmet documentation** and **respiratory assistance**. Race, ethnicity, and payer are included only in the categorical **disposition** and **hospital-LOS trajectory** models, where they are treated as social/health-system contextual variables rather than biological causes.

## Validation strategy

Manuscript-facing performance is based on **rolling-origin temporal evaluation**, not random cross-validation:

- train 2020 -> tune 2021 -> evaluate 2022;
- train 2020-2021 -> tune 2022 -> evaluate 2023;
- train 2020-2022 -> tune 2023 -> evaluate 2024.

After the model specification was locked, full-development 5-fold cross-validation on 2020-2024 was used **only to select boosting rounds for the deployment models**. Those 5-fold CV results are not treated as independent validation.

External validation should be performed on data not used during model development.

## Repository layout

```text
TBI-TRACT/
├── README.md
├── CODE_AVAILABILITY.md
├── PIPELINE_MANIFEST.csv
├── .gitignore
├── R/
│   └── 00_config.example.R
├── analysis/
├── sensitivity/
├── deployment/
├── reporting/
└── docs/
```

See `PIPELINE_MANIFEST.csv` for the ordered workflow and whether a script is part of the locked final analysis, a sensitivity analysis, or historical model development.

## Running the analysis

1. Obtain the ACS TQIP/TQP PUF files locally.
2. Copy `R/00_config.example.R` to `R/00_config.R`.
3. Set the local PUF root and output directory.
4. Add the local cohort-construction / harmonization scripts identified as `ADD_FROM_LOCAL_REPO` in `PIPELINE_MANIFEST.csv`.
5. Run the ordered pipeline stages required for the intended reproduction target.

### Minimal final-analysis sequence after the harmonized cohort exists

```r
source("analysis/09_TBI_TRACT_temporal_hyperparameter_tuning_v3.R")
source("sensitivity/23_run_TBI_TRACT_pragmatic_finalist_retune_GPU.R")
source("sensitivity/24_run_TBI_TRACT_pragmatic_duration_finalization_GPU.R")
source("sensitivity/25_run_TBI_TRACT_final_sensitivity_suite_GPU.R")
source("deployment/26_run_TBI_TRACT_deployment_temporal_CV_GPU_v2.R")
source("deployment/26b_extend_TBI_TRACT_hospital_LOS_deployment_CV_GPU.R")
source("reporting/27_build_TBI_TRACT_manuscript_output_data.R")
source("reporting/29_build_TBI_TRACT_final_figures_REFINED.R")
```

The complete sensitivity/reviewer-facing workflow is specified in `PIPELINE_MANIFEST.csv`.

## Software

Final development was performed in **R 4.6.0** on Windows x86-64. GPU-enabled XGBoost training used a Python XGBoost **3.2.0** CUDA environment accessed from R through `reticulate`; the R XGBoost package version used during development was **3.2.1.1**. The analysis was developed on a workstation with an NVIDIA RTX 4090 GPU, although exact hardware is not conceptually required if equivalent XGBoost objectives and parameters are supported.

Packages detected in the included scripts include:

data.table, ggplot2, grid, parallel, patchwork, reticulate, scales, splines, xgboost

For publication, a frozen dependency record (for example `renv.lock` plus the Python/conda environment specification) should be committed from the machine used for the final run.

## Reproducibility and restricted data

This repository intentionally excludes:

- raw ACS PUF files;
- row-level derived patient data;
- local paths/configuration;
- credentials;
- generated results that could violate underlying data-use terms.

If permitted by the ACS data-use terms, the **final trained model objects and encoders** should be archived separately as versioned release assets (preferably in a DOI-bearing repository such as Zenodo) because several trained objects exceed ordinary GitHub web-upload limits.

## Citation

If this repository is used after publication, cite the accompanying TBI-TRACT manuscript and the archived software release DOI.

## License

Choose and add a software license before public release. Do not add an open-source license automatically if institutional or data-use restrictions have not been reviewed.
