# TBI-TRACT public pipeline helper
#
# This does NOT download or distribute ACS data.
# It assumes the harmonized analytic dataset has already been created locally.

required_files <- c(
  "R/00_config.R",
  "analysis/09_TBI_TRACT_temporal_hyperparameter_tuning_v3.R",
  "sensitivity/23_run_TBI_TRACT_pragmatic_finalist_retune_GPU.R",
  "sensitivity/24_run_TBI_TRACT_pragmatic_duration_finalization_GPU.R",
  "sensitivity/25_run_TBI_TRACT_final_sensitivity_suite_GPU.R",
  "deployment/26_run_TBI_TRACT_deployment_temporal_CV_GPU_v2.R",
  "deployment/26b_extend_TBI_TRACT_hospital_LOS_deployment_CV_GPU.R",
  "reporting/27_build_TBI_TRACT_manuscript_output_data.R"
)

missing <- required_files[!file.exists(required_files)]

if (length(missing) > 0L) {
  stop(
    "Missing required pipeline file(s):\n",
    paste(missing, collapse = "\n"),
    call. = FALSE
  )
}

source("analysis/09_TBI_TRACT_temporal_hyperparameter_tuning_v3.R")
source("sensitivity/23_run_TBI_TRACT_pragmatic_finalist_retune_GPU.R")
source("sensitivity/24_run_TBI_TRACT_pragmatic_duration_finalization_GPU.R")
source("sensitivity/25_run_TBI_TRACT_final_sensitivity_suite_GPU.R")
source("deployment/26_run_TBI_TRACT_deployment_temporal_CV_GPU_v2.R")
source("deployment/26b_extend_TBI_TRACT_hospital_LOS_deployment_CV_GPU.R")
source("reporting/27_build_TBI_TRACT_manuscript_output_data.R")

message("TBI-TRACT final analytic pipeline completed.")
