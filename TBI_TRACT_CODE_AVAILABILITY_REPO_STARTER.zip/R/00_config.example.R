# TBI-TRACT public configuration template
# Copy to R/00_config.R and edit for your local environment.

# Root directory containing locally obtained ACS TQIP/TQP PUF files.
# Raw patient-level data are intentionally not included in this repository.
data_root <- Sys.getenv(
  "TBI_TRACT_DATA_ROOT",
  unset = "PATH/TO/LOCAL/TQIP"
)

# Directory for derived analysis outputs.
output_dir <- Sys.getenv(
  "TBI_TRACT_OUTPUT_DIR",
  unset = file.path(getwd(), "output")
)

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# Optional: if your local cohort-construction scripts use explicit year paths,
# define them here rather than hard-coding machine-specific locations.
tqip_years <- 2020:2024

# GPU-enabled XGBoost environment used for the final development work.
python_conda_env <- Sys.getenv(
  "TBI_TRACT_CONDA_ENV",
  unset = "tbi-tract-xgb-gpu"
)

# Reproducibility seed used throughout final analyses.
analysis_seed <- 20260913L
