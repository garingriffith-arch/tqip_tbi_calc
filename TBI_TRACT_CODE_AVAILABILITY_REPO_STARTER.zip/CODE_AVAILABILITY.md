# Code and model availability

## Manuscript-ready Code Availability statement

Analytic code used for cohort processing, model development, rolling-origin temporal evaluation, sensitivity analyses, calibration assessment, and manuscript output generation is available at **[GITHUB URL]**. A versioned archival release of the code will be deposited at **[ZENODO DOI / ARCHIVAL URL]**. The ACS TQIP/TQP Participant Use Files are not redistributed by the authors; investigators seeking to reproduce the analyses must obtain the source data independently from the American College of Surgeons and comply with the applicable data-use terms.

Final trained model objects and preprocessing/encoder objects are available at **[MODEL ARCHIVE URL]**, subject to confirmation that redistribution is permitted under the applicable ACS data-use terms. The repository documents the software environment, predictor definitions, model specifications, and instructions needed to generate predictions in new data.

## If trained model objects cannot be redistributed

Use this version instead:

Analytic code used for cohort processing, model development, rolling-origin temporal evaluation, sensitivity analyses, calibration assessment, and manuscript output generation is available at **[GITHUB URL]**, with a versioned archival release at **[ZENODO DOI / ARCHIVAL URL]**. The ACS TQIP/TQP Participant Use Files are not redistributed by the authors; investigators must obtain the source data independently from the American College of Surgeons and comply with applicable data-use terms. Because distribution of trained model objects is subject to the underlying data-use agreement, the public repository provides the complete model specification and training pipeline; access to trained objects will be provided as permitted by those terms.

## JAMA-style Data Sharing Statement draft

**Data Sharing Statement:** The ACS TQIP/TQP Participant Use Files used in this study are subject to access and data-use requirements and cannot be redistributed by the authors. Analytic code and supporting documentation are publicly available at **[GITHUB URL]** and archived at **[ZENODO DOI / ARCHIVAL URL]**. Availability of trained model objects is described in the repository and is subject to applicable source-data use restrictions.

## What should be public before submission or acceptance

At minimum, the linked repository should contain:

- a README describing the intended prediction time and model outputs;
- cohort/variable derivation code or sufficiently explicit reproducible cohort-construction scripts;
- final model-training and temporal-evaluation scripts;
- all final sensitivity-analysis scripts cited in the manuscript;
- table/figure-generation code;
- predictor and outcome definitions;
- an example configuration file with no local paths or credentials;
- package/software versions;
- a pipeline manifest / run order;
- instructions for obtaining the source data;
- if legally permitted, final trained model objects and preprocessing/encoder objects.

A frozen DOI-bearing archive is preferable for the version cited by the final manuscript so the exact analyzed code remains recoverable even if the GitHub repository evolves.
